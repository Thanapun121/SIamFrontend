import Navbar from "../components/Navbar";
import "bootstrap/dist/css/bootstrap.min.css";
import Head from 'next/head';
import { useEffect, useState } from 'react';
import Image from 'next/image';

export default function ImagePage() {
  const [images, setImages] = useState([]);
  const [filteredImages, setFilteredImages] = useState([]);
  const [filterRoom, setFilterRoom] = useState('');
  const [filterSubject, setFilterSubject] = useState('');
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');
  const [filterStartTime, setFilterStartTime] = useState('');
  const [filterEndTime, setFilterEndTime] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('/api/images');
        const data = await response.json();
        console.log('Data from API:', data);
        if (Array.isArray(data)) {
          setImages(data);
          setFilteredImages(data);
        } else {
          console.error('API did not return an array');
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);

  const formatTime = (timeString) => {
    const hours = timeString.substring(0, 2);
    const minutes = timeString.substring(2, 4);
    const seconds = timeString.substring(4, 6);
    return `${hours}:${minutes}:${seconds}`;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const localDate = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
    return localDate.toISOString().split('T')[0];
  };

  const convertTimeToISO = (timeString) => {
    if (!timeString) return '00:00:00';
    return timeString.padStart(8, '0');
  };

  const filterData = () => {
    const filtered = images.filter(image => {
      const imageDate = formatDate(image.imagedate || '');
      const imageTime = formatTime(image.imagetime ? image.imagetime.split('-')[0] : '000000');

      const startDate = filterStartDate ? formatDate(filterStartDate) : '';
      const endDate = filterEndDate ? formatDate(filterEndDate) : '';
      const startTime = filterStartTime ? convertTimeToISO(filterStartTime) : '00:00:00';
      const endTime = filterEndTime ? convertTimeToISO(filterEndTime) : '23:59:59';

      const isRoomMatch = filterRoom ? (image.room || '').toLowerCase().includes(filterRoom.toLowerCase()) : true;
      const isSubjectMatch = filterSubject ? (image.subjectname || '').toLowerCase().includes(filterSubject.toLowerCase()) : true;
      const isDateInRange = (!startDate || imageDate >= startDate) && (!endDate || imageDate <= endDate);
      const isTimeInRange = (imageTime >= startTime) && (imageTime <= endTime);

      return isRoomMatch && isSubjectMatch && (filterStartDate || filterEndDate ? (isDateInRange && isTimeInRange) : isTimeInRange);
    });

    setFilteredImages(filtered);
  };

  const clearFilters = () => {
    setFilterRoom('');
    setFilterSubject('');
    setFilterStartDate('');
    setFilterEndDate('');
    setFilterStartTime('');
    setFilterEndTime('');
    setFilteredImages(images);
  };

  return (
    <main>
      <Head>
        <title>Image</title>
      </Head>
      <Navbar />

      <div style={{ marginTop: '20px', marginBottom: '20px' }}>
        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
          <div>
            <label>Room: </label>
            <input
              type="text"
              value={filterRoom}
              onChange={(e) => setFilterRoom(e.target.value)}
              placeholder="กรอกชื่อ room ที่ต้องการกรอง"
            />
          </div>
          <div>
            <label>Subject: </label>
            <input
              type="text"
              value={filterSubject}
              onChange={(e) => setFilterSubject(e.target.value)}
              placeholder="กรอกชื่อวิชา"
            />
          </div>
          <div>
            <label>Start Date: </label>
            <input
              type="date"
              value={filterStartDate}
              onChange={(e) => setFilterStartDate(e.target.value)}
            />
          </div>
          <div>
            <label>End Date: </label>
            <input
              type="date"
              value={filterEndDate}
              onChange={(e) => setFilterEndDate(e.target.value)}
            />
          </div>
          <div>
            <label>Start Time (HH:mm:ss): </label>
            <input
              type="text"
              value={filterStartTime}
              onChange={(e) => setFilterStartTime(e.target.value)}
              placeholder="เช่น 08:00:00"
            />
          </div>
          <div>
            <label>End Time (HH:mm:ss): </label>
            <input
              type="text"
              value={filterEndTime}
              onChange={(e) => setFilterEndTime(e.target.value)}
              placeholder="เช่น 09:00:00"
            />
          </div>
          <div>
            <button onClick={filterData} className="btn btn-primary">Filter</button>
            <button onClick={clearFilters} className="btn btn-secondary" style={{ marginLeft: '10px' }}>Clear Filter</button>
          </div>
        </div>
      </div>

      <table className="table table-bordered" style={{ marginTop: '20px' }}>
        <thead>
          <tr>
            <th>Room / Date / Time</th>
            <th>Subject</th>
            <th>Image Original</th>
            <th>Image Prediction</th>
            <th>CSV Download</th>
          </tr>
        </thead>
        <tbody>
          {filteredImages.map((image, index) => {
            const subjectName = (image.subjectname !== null) ? image.subjectname : 'Unknown';
            const imagePath = image.imagepath ? `/${image.imagepath}` : '/placeholder-image.jpg';
            const processPath = image.processpath ? `/${image.processpath}` : '/placeholder-image.jpg';

            return (
              <tr key={index}>
                <td>
                  Room = {image.room} <br />
                  Date = {formatDate(image.imagedate || '')} <br />
                  Time = {formatTime(image.imagetime ? image.imagetime.split('-')[0] : '000000')}
                </td>
                <td>{subjectName}</td>
                <td>
                  <Image
                    src={imagePath}
                    alt={image.imagename || 'Image'}
                    width={300}
                    height={200}
                    style={{ marginRight: '10px' }}
                  />
                </td>
                <td>
                  <Image
                    src={processPath}
                    alt={image.imagename || 'Image'}
                    width={300}
                    height={200}
                    style={{ marginRight: '10px' }}
                  />
                </td>
                <td>
                  {image.seat ? (
                    <a href={`/${image.seat}`} download>
                      Download CSV
                    </a>
                  ) : (
                    'CSV is not available'
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </main>
  );
}
