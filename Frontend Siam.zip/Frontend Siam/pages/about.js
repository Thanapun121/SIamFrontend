import Navbar from "../components/Navbar"
import "bootstrap/dist/css/bootstrap.min.css";
import Head from 'next/head';


export default function About() {
    return (
        <main>
            <Head>
                <title>About</title>
            </Head>
            <Navbar/>
        </main>
    )
}