import { useState } from 'react';
import { useRouter } from 'next/router';
import styles from '../styles/Login.module.css';
import Image from 'next/image';
import myImage from '../src/images/medsiam.png';
import Link from 'next/link';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (username === 'admin' && password === 'admin') {
      router.push('/dashboard');
    } else {
      setError('Invalid username or password');
    }
  };

  return (
    <div className={styles.container}>
      <form className={styles.form} onSubmit={handleSubmit}>
        <Image src={myImage} alt="" width={200} height={200} />
        <h1 className="h3 mb-3 fw-normal">Please login</h1>
        {error && <p className={styles.error}>{error}</p>}
        <input type="text" 
          className="from-control"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
        <input
          type="password"
          className="from-control"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button type="submit">Login</button>
        <Link href="/" className="d-inline-flex link-body-emphasis text-decoration-none" style={{ padding: '20px'}}>
            Home
        </Link>
        <Link href="/register" className="d-inline-flex link-body-emphasis text-decoration-none" style={{ padding: '20px'}}>
            Register
        </Link>
      </form>
    </div>
  );
}