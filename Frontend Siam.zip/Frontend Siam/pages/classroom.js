import { useState } from 'react';
import Head from 'next/head';
import Navbar from '../components/Navbar';

export default function ClassroomPage() {
  const [subjectName, setSubjectName] = useState('');
  const [dayInWeek, setDayInWeek] = useState('');
  const [dateStart, setDateStart] = useState('');
  const [dateEnd, setDateEnd] = useState('');
  const [timeRange, setTimeRange] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
  
    try {
      const response = await fetch('/api/subjects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          subjectname: subjectName,
          dayinweek: dayInWeek,
          datestart: dateStart,
          dateend: dateEnd,
          timerange: timeRange,
        }),
      });
  
      if (!response.ok) {
        const errorText = await response.text(); // ใช้ text() เพื่อดูข้อความที่ไม่ใช่ JSON
        throw new Error(`Error: ${errorText}`);
      }
  
      const responseData = await response.json();
      alert('Subject added successfully');
      // Reset form fields
      setSubjectName('');
      setDayInWeek('');
      setDateStart('');
      setDateEnd('');
      setTimeRange('');
    } catch (error) {
      alert(`Failed to add subject: ${error.message}`);
    }
  };
  

  return (
    <main>
      <Head>
        <title>Classroom</title>
      </Head>
      <Navbar />
      
      <div style={{ marginTop: '20px', marginBottom: '20px' }}>
        <form onSubmit={handleSubmit}>
          <div>
            <label>Subject Name: </label>
            <input
              type="text"
              value={subjectName}
              onChange={(e) => setSubjectName(e.target.value)}
              required
            />
          </div>
          <div>
            <label>Day in Week: </label>
            <input
              type="text"
              value={dayInWeek}
              onChange={(e) => setDayInWeek(e.target.value)}
              required
            />
          </div>
          <div>
            <label>Start Date: </label>
            <input
              type="date"
              value={dateStart}
              onChange={(e) => setDateStart(e.target.value)}
              required
            />
          </div>
          <div>
            <label>End Date: </label>
            <input
              type="date"
              value={dateEnd}
              onChange={(e) => setDateEnd(e.target.value)}
              required
            />
          </div>
          <div>
            <label>Time Range: </label>
            <input
              type="text"
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary">Add Subject</button>
        </form>
      </div>
    </main>
  );
}
