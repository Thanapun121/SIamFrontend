import Navbar from "../components/Navbar"
import "bootstrap/dist/css/bootstrap.min.css";
import Head from 'next/head';
import { useState } from 'react'; // Import useState from 'react'

export default function Register() {
    const [formData, setFormData] = useState({
        firstname: '',
        lastname: '',
        username: '',
        email: '',
        password: '',
        confirmpassword: '',
    });
    
    const [errors, setErrors] = useState({});
    
    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };
    
    const handleSubmit = async (e) => {
        e.preventDefault();
    
        // Basic client-side validation
        let currentErrors = {};
        if (!formData.firstname) currentErrors.firstname = 'Firstname is required';
        if (!formData.lastname) currentErrors.lastname = 'Lastname is required';
        if (!formData.username) currentErrors.username = 'Username is required';
        if (!formData.email) currentErrors.email = 'Email is required';
        if (!formData.password) currentErrors.password = 'Password is required';
        if (formData.password !== formData.confirmPassword) currentErrors.confirmPassword = 'Passwords must match';
    
        setErrors(currentErrors);
    
        if (Object.keys(currentErrors).length === 0) {
            try {
                // Send the form data to an API endpoint
                const response = await fetch('/api/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });
    
            const result = await response.json();
            if (response.ok) {
                alert('Registration successful!');
                // Redirect or handle successful registration
            } else {
                alert(result.message || 'Something went wrong!');
            }
            } catch (error) {
                console.error('Error:', error);
            }
        }
    };
    
      return (
        <div>
            <Head>
                <title>Register</title>
            </Head>
            <Navbar/>
            <form onSubmit={handleSubmit}>
                <div>
                    <label class="mb-4" style={{ paddingLeft: '60px'}}>Firstname</label>
                    <input
                        type="text"
                        name="firstname"
                        value={formData.firstname}
                        onChange={handleChange}
                        style={{ marginLeft: '90px' }}
                    />
                    {errors.firstname && <p>{errors.firstname}</p>}
                </div>
                <div>
                    <label class="mb-4" style={{ paddingLeft: '60px'}}>Lastname</label>
                    <input
                        type="text"
                        name="lastname"
                        value={formData.lastname}
                        onChange={handleChange}
                        style={{marginLeft: '90px' }}
                    />
                    {errors.lastname && <p>{errors.lastname}</p>}
                </div>
                <div>
                    <label class="mb-4" style={{ paddingLeft: '60px'}}>Username</label>
                    <input
                        type="text"
                        name="username"
                        value={formData.username}
                        onChange={handleChange}
                        style={{marginLeft: '87px' }}
                    />
                    {errors.username && <p>{errors.username}</p>}
                </div>
                <div>
                    <label class="mb-4" style={{ paddingLeft: '60px'}}>Email</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        style={{marginLeft: '120px' }}
                    />
                    {errors.email && <p>{errors.email}</p>}
                </div>
                <div>
                    <label class="mb-4" style={{ paddingLeft: '60px'}}>Password</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        style={{marginLeft: '93px' }}
                    />
                    {errors.password && <p>{errors.password}</p>}
                </div>
                <div>
                    <label class="mb-4" style={{ paddingLeft: '60px'}}>Confirm Password</label>
                    <input
                        type="password"
                        name="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        style={{marginLeft: '31px' }}
                    />
                    {errors.confirmPassword && <p>{errors.confirmPassword}</p>}
                </div>
                <button type="submit" className="btn btn-secondary" style={{ marginLeft: '320px'}}>Register</button>
            </form>
        </div>
      );
}
