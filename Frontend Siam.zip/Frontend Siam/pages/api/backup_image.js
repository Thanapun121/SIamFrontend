import mysql from 'mysql2/promise';

export default async function handler(req, res) {
  const connection = await mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'admin',
    database: 'siam',
  });

  try {
    // JOIN ตาราง images และ subjects เพื่อดึงข้อมูล subjectname
    const [rows] = await connection.execute(
      'SELECT images.imagename, images.imagepath, images.processpath, images.seat, images.room, images.imagedate, images.imagetime FROM images');
    res.status(200).json(rows);
  } catch (error) {
    res.status(500).json({ error: 'Database query error' });
  } finally {
    await connection.end();
  }
}
