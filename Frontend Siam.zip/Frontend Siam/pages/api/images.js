import mysql from 'mysql2/promise';

export default async function handler(req, res) {
  const connection = await mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'admin',
    database: 'siam',
  });

  try {
    const [rows] = await connection.execute(
      `SELECT images.imagename, images.imagepath, images.processpath, images.seat, images.room, 
              images.imagedate, images.imagetime, subjects.subjectname 
       FROM images 
       JOIN subjects ON images.subjectid = subjects.subjectid`
    );

    console.log('Rows from database:', rows); // ตรวจสอบข้อมูลที่ดึงมาจากฐานข้อมูล
    res.status(200).json(rows); // ส่งข้อมูลไปยัง client
  } catch (error) {
    console.error('Error during database query:', error); // แสดงข้อผิดพลาดใน console
    res.status(500).json({ error: 'Database query error' });
  } finally {
    await connection.end(); // ปิดการเชื่อมต่อ
  }
}
