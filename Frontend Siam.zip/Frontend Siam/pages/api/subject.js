import mysql from 'mysql2/promise';

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { subjectname, dayinweek, datestart, dateend, timerange } = req.body;

    if (!subjectname || !dayinweek || !datestart || !dateend || !timerange) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const connection = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: 'admin',
      database: 'siam',
    });

    try {
      const [result] = await connection.execute(
        'INSERT INTO subjects (subjectname, dayinweek, datestart, dateend, timerange) VALUES (?, ?, ?, ?, ?)',
        [subjectname, dayinweek, datestart, dateend, timerange]
      );

      res.status(201).json({ message: 'Subject added successfully' });
    } catch (error) {
      console.error('Database query error:', error); // เพิ่มการแสดงข้อผิดพลาดในเซิร์ฟเวอร์
      res.status(500).json({ error: 'Database query error' });
    } finally {
      await connection.end();
    }
  } else {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
