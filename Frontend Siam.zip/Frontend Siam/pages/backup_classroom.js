import Navbar from "../components/Navbar"
import "bootstrap/dist/css/bootstrap.min.css";
import Head from 'next/head';
import { useRouter } from 'next/navigation';

export default function Classroom() {
    const router = useRouter();

    const handleButtonClick = () => {
        router.push('/addclassroom');
    };

    return (
        <main>
            <Head>
                <title>Classroom</title>
            </Head>
            <Navbar/>
            <div className="d-grid gap-2 d-sm-flex">
              <button type="button" className="btn btn-outline-secondary" onClick={handleButtonClick}>Add Classroom</button>
            </div>
        </main>
    )
}