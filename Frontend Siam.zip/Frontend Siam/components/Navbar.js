'use client';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import "bootstrap/dist/css/bootstrap.min.css";
import { useState } from 'react';

export default function Navbar() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const router = useRouter();

  const handleLoginLogout = () => {
    if (isLoggedIn) {
      setIsLoggedIn(false); // Log the user out
    } else {
      router.push('/login'); // Redirect to login page
    }
  };

  return (
    <main>
      <div className="container-fluid">
        <header
          className="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom"
          style={{ backgroundColor: 'green' }}
        >
          <div className="col-md-3 mb-2 mb-md-0" style={{ paddingLeft: '20px' }}>
            <Link href="/" className="d-inline-flex text-decoration-none" style={{ color: 'white' }}>
              Siam CCTV
            </Link>
          </div>
          <ul className="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
            <li><Link href="/" className="nav-link px-2" style={{ color: 'white' }}>Home</Link></li>
            <li><Link href="/image" className="nav-link px-2" style={{ color: 'white' }}>Image</Link></li>
            <li><Link href="/classroom" className="nav-link px-2" style={{ color: 'white' }}>Classroom</Link></li>
          </ul>
          <div className="col-md-3 text-end" style={{ paddingRight: '20px' }}>
            <button
              type="button"
              className="btn btn-primary"
              onClick={handleLoginLogout}
            >
              {isLoggedIn ? 'Logout' : 'Login'}
            </button>
          </div>
        </header>
      </div>
    </main>
  );
}
