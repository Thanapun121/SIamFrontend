/** @type {import('next').NextConfig} */
const nextConfig = {
    reactStrictMode: true, // เปิด strict mode
    images: {
      // กำหนดว่าคุณต้องการอนุญาตให้โหลดภาพจาก localhost
      domains: ['localhost'],
      // ปรับขนาดภาพให้เหมาะสมโดยไม่จำเป็นต้องใช้ external loaders
      deviceSizes: [640, 768, 1024, 1280, 1600],
      imageSizes: [16, 32, 48, 64, 96],
    },
};

export default nextConfig;