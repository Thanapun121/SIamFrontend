import Image from 'next/image';
import myImage from '../images/medsiam.png'; // Import the imag
import Navbar from '../../components/Navbar';
import "bootstrap/dist/css/bootstrap.min.css";

export default function Home() {
  return (
    <main>

      <Navbar/>

      <div class="px-4 py-5 my-5 text-center">
        <Image 
          src={myImage} // Image source
          alt="" // Image alt text for accessibility
          width={400} // Image width in pixels
          height={400} // Image height in pixels
        />
        <h1 class="display-5 fw-bold text-body-emphasis">Medical School Timetable</h1>
        <div class="col-lg-6 mx-auto">
          <p class="lead mb-4">"We record images from CCTV cameras every 5 minutes during classes as evidence of attendance. If the displayed information does not match your actual attendance, you can notify the staff to verify the evidence."</p>
        </div>
      </div>
    </main>
  );
}